var searchData=
[
  ['zoom_0',['Zoom',['../class_camera.html#a2becf27d08eb7e6da9c597c73ea95b5d',1,'Camera']]],
  ['zoom_1',['ZOOM',['../camera_8h.html#ad53f4ea4bad2000e469a9b538c39878f',1,'camera.h']]]
];
