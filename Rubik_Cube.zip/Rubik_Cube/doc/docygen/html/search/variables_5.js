var searchData=
[
  ['issolved_0',['isSolved',['../cube_8cpp.html#ac39a27f0e4ad0cde977459bc21fa36fd',1,'isSolved:&#160;cube.cpp'],['../cube_8h.html#ac39a27f0e4ad0cde977459bc21fa36fd',1,'isSolved:&#160;cube.cpp']]]
];
