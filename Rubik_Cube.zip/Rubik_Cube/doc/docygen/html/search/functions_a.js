var searchData=
[
  ['turn_5fcube_5fdown_5fto_5fup_0',['turn_cube_down_to_up',['../cube_8cpp.html#af543e2edc12e8ead355d94005cacea57',1,'turn_cube_down_to_up(int which, int each, bool game):&#160;cube.cpp'],['../cube_8h.html#af543e2edc12e8ead355d94005cacea57',1,'turn_cube_down_to_up(int which, int each, bool game):&#160;cube.cpp']]],
  ['turn_5fcube_5fleft_5fto_5fright_1',['turn_cube_left_to_right',['../cube_8cpp.html#acfbdaef2f75d1f8b120716c251bf84a5',1,'turn_cube_left_to_right(int which, int each, bool game):&#160;cube.cpp'],['../cube_8h.html#acfbdaef2f75d1f8b120716c251bf84a5',1,'turn_cube_left_to_right(int which, int each, bool game):&#160;cube.cpp']]],
  ['turn_5fcube_5fright_5fto_5fleft_2',['turn_cube_right_to_left',['../cube_8cpp.html#a11193bd495bdd0ecd2537f17f0724286',1,'turn_cube_right_to_left(int which, int each, bool game):&#160;cube.cpp'],['../cube_8h.html#a11193bd495bdd0ecd2537f17f0724286',1,'turn_cube_right_to_left(int which, int each, bool game):&#160;cube.cpp']]],
  ['turn_5fcube_5fto_5ffull_3',['turn_cube_to_full',['../cube_8cpp.html#a7b8109a47240fba6e810e79c2022e2c7',1,'turn_cube_to_full():&#160;cube.cpp'],['../cube_8h.html#a7b8109a47240fba6e810e79c2022e2c7',1,'turn_cube_to_full():&#160;cube.cpp']]],
  ['turn_5fcube_5fup_5fto_5fdown_4',['turn_cube_up_to_down',['../cube_8cpp.html#a3ac1ba4d1cbc975ea13f57957ede7c6d',1,'turn_cube_up_to_down(int which, int each, bool game):&#160;cube.cpp'],['../cube_8h.html#a3ac1ba4d1cbc975ea13f57957ede7c6d',1,'turn_cube_up_to_down(int which, int each, bool game):&#160;cube.cpp']]]
];
