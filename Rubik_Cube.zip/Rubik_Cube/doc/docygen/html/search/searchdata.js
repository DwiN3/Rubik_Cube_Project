var indexSectionsWithContent =
{
  0: "abcdefgiklmprstuwyz",
  1: "cs",
  2: "cms",
  3: "cdfgiklmpstu",
  4: "acdefilmprstuwyz",
  5: "s",
  6: "c",
  7: "bflrs",
  8: "cs"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Macros"
};

