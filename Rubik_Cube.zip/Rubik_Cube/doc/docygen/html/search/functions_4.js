var searchData=
[
  ['is_5fcube_5fsolved_0',['is_cube_solved',['../cube_8cpp.html#a2a36dd6303f6cf4433d4c2603c1003c0',1,'is_cube_solved():&#160;cube.cpp'],['../cube_8h.html#a2a36dd6303f6cf4433d4c2603c1003c0',1,'is_cube_solved():&#160;cube.cpp']]]
];
